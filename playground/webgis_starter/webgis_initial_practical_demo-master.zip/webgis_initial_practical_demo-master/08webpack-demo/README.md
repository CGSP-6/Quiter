# webpack demo

使用 webpack 环境开发和预览 dmeo

## 使用方式

根目录执行: npm install

启动： npm run start

打包部署： npm run build ，将生成的 dist 目录下的文件部署即可。
