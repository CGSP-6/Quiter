# 12-ol-rainlayer-demo

雨水发布图，使用 webpack 环境开发的，基于 openlayers，学习的同学，可以对比一下 demo11，leaflet 实现的方式。个人感觉 leaflet 相对可能简单一些。

## 使用方式

根目录执行: `npm install` ，安装依赖

启动： `npm run start`

打包部署： `npm run build` ，将生成的 dist 目录下的文件部署即可。

## 源码

全部功能源码见 `./app.js`
